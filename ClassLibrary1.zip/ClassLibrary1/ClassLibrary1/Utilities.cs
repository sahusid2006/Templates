﻿using System;
using System.IO;
using System.Xml;
using System.Xml.Linq;
using System.Xml.XPath;
using Newtonsoft.Json;

namespace Utilities
{
    public class Utilities
    {
        public static string XPathNavigator(string path, string node)
        {
            try
            {
                XPathNavigator nav;
                XPathDocument docNav;
                string xPath;
                docNav = new XPathDocument(path);
                nav = docNav.CreateNavigator();
                xPath = "//ConfigFile/" + node;
                string value = nav.SelectSingleNode(xPath).Value;
                return value;
            }
            catch(NullReferenceException)
            {
                throw new NullReferenceException("Unable to find any object at the XPath" + node);
            }
            catch(FileNotFoundException)
            {
                throw new FileNotFoundException("Unable to Find file: " + path);
            }
            catch(IOException)
            {
                throw new FileNotFoundException("You probably have the string file open :)");
            }
            catch(Exception)
            {
                throw new Exception("Unknown Exception");
            }
        }

        // ###################################################################################################################################################################

        public static string EnvironmentXPathNavigator(string path, string node, string cr)
        {
            try
            {
                XPathNavigator Envmtnav;
                XPathDocument docNav;
                string xPathEnvmt, xPathURLRnd, xPathURLUAT, xPathURLQA, xPathURLProd;
                docNav = new XPathDocument(path);
                Envmtnav = docNav.CreateNavigator();

                xPathURLRnd = "//ConfigFile/URLRnDCR";
                string URLRnd = Envmtnav.SelectSingleNode(xPathURLRnd).Value;

                xPathURLUAT = "//ConfigFile/URLUATCR";
                string URLUAT = Envmtnav.SelectSingleNode(xPathURLUAT).Value;

                xPathURLQA = "//ConfigFile/URLQACR";
                string URLQA = Envmtnav.SelectSingleNode(xPathURLQA).Value;

                xPathURLProd = "//ConfigFile/URLProdCR";
                string URLProd = Envmtnav.SelectSingleNode(xPathURLProd).Value;

                string envmt = "";

                if (cr == URLRnd)
                {
                    envmt = "Dev";
                }
                if (cr == URLUAT)
                {
                    envmt = "UAT";
                }
                if (cr == URLQA)
                {
                    envmt = "QA";
                }
                if (cr == URLProd)
                {
                    envmt = "Prod";
                }

                xPathEnvmt = "//ConfigFile/" + envmt + "/" + node;
                string value = Envmtnav.SelectSingleNode(xPathEnvmt).Value;
                return value;
            }
            catch (NullReferenceException)
            {
                throw new NullReferenceException("Unable to find any object at the XPath" + node);
            }
            catch (FileNotFoundException)
            {
                throw new FileNotFoundException("Unable to Find file: " + path);
            }
            catch (IOException)
            {
                throw new FileNotFoundException("You probably have the string file open :)");
            }
            catch (Exception)
            {
                throw new Exception("Unknown Exception");
            }
        }

        // ###################################################################################################################################################################

        public static string TestVariableSwitchValue(string path)
        {
            try
            {
                XPathNavigator nav;
                XPathDocument docNav;
                string xPathSwitch;
                docNav = new XPathDocument(path);
                nav = docNav.CreateNavigator();
                xPathSwitch = "//ConfigFile/TestVariableSwitch";
                string switchvalue = nav.SelectSingleNode(xPathSwitch).Value;
                return switchvalue;

            }
            catch (NullReferenceException)
            {
                throw new NullReferenceException("Unable to find any object at the XPath: //ConfigFile/TestSwitch. Check if this node exists");
            }
            catch (FileNotFoundException)
            {
                throw new FileNotFoundException("Unable to Find file: " + path);
            }
            catch (IOException)
            {
                throw new FileNotFoundException("You probably have the string file open :)");
            }
            catch (Exception)
            {
                throw new Exception("Unknown Exception");
            }
        }
        // ###################################################################################################################################################################

        public static string TestMessageSwitchValue(string path)
        {
            try
            {
                XPathNavigator nav;
                XPathDocument docNav;
                string xPathSwitch;
                docNav = new XPathDocument(path);
                nav = docNav.CreateNavigator();
                xPathSwitch = "//ConfigFile/TestMessageSwitch";
                string switchvalue = nav.SelectSingleNode(xPathSwitch).Value;
                return switchvalue;

            }
            catch (NullReferenceException)
            {
                throw new NullReferenceException("Unable to find any object at the XPath: //ConfigFile/TestSwitch. Check if this node exists");
            }
            catch (FileNotFoundException)
            {
                throw new FileNotFoundException("Unable to Find file: " + path);
            }
            catch (IOException)
            {
                throw new FileNotFoundException("You probably have the string file open :)");
            }
            catch (Exception)
            {
                throw new Exception("Unknown Exception");
            }
        }
        
        // ###################################################################################################################################################################

        public static string TestValueXPath(string path, string testkey)
        {
            try
            {
                    XPathNavigator nav;
                    XPathDocument docNav;
                    docNav = new XPathDocument(path);
                    nav = docNav.CreateNavigator();
                    string XPathtestvalue;
                    XPathtestvalue = "//ConfigFile/TestValues/" + testkey;
                    string testvalue = nav.SelectSingleNode(XPathtestvalue).Value;
                    return testvalue;
            }
            catch (NullReferenceException)
            {
                throw new NullReferenceException("Unable to find any object at the XPath: //ConfigFile/TestValues/" + testkey);
            }
            catch (FileNotFoundException)
            {
                throw new FileNotFoundException("Unable to Find file: " + path);
            }
            catch (IOException)
            {
                throw new FileNotFoundException("You probably have the string file open :)");
            }
            catch (Exception)
            {
                throw new Exception("Unknown Exception");
            }
        }

        // ###################################################################################################################################################################

        public static void LogToFile(string path, string RobotName, string TaskName, string Activity, string Description)
        {
            try
            {
                using (var w = new StreamWriter(path))
                {
                    var line = string.Format("{0},{1},{2},{3}", RobotName, TaskName, Activity, Description);
                    w.WriteLine(line);
                    w.Flush();
                }
            }
            catch(DirectoryNotFoundException)
            {
                throw new FileNotFoundException("Unable to find file:" + path);
            }
            catch(FileNotFoundException)
            {
                throw new FileNotFoundException("Unable to find file:" + path);
            }
            catch (IOException)
            {
                throw new FileNotFoundException("You probably have the string file open :)");
            }
            catch (Exception)
            {
                throw new Exception("Unknown Exception");
            }
        }

    }
}