﻿using System;

namespace MetabotFramework
{
    public class MetabotTest
    {
		public static string ToCaps(string str)
		{
			return str.ToUpper();
		}
    }
}
