﻿    using System;

namespace DateFunctions
{
	public class DateTimeWrapper
	{

		public static DateTime Date;

        private static DateTime StartDateTime;
        private static DateTime StopDateTime;
        private static bool IsTiming;

		public DateTimeWrapper()
		{
            IsTiming = false;
		}

		private void SetDateTime(string str)
		{
			Date = Convert.ToDateTime(str);
		}
		
		public string GetDateTime(string str)
		{
			SetDateTime(str);
			return Date.ToString();
		}

		public string Day(string str)
		{
			SetDateTime(str);
			return Date.Day.ToString();
		}
	
		public string Month(string str)
		{
			SetDateTime(str);
			return Date.Month.ToString();
		}

		public string Year(string str)
		{
			SetDateTime(str);
			return Date.Year.ToString();
		}

		public string DayOfWeek(string str)
		{
			SetDateTime(str);
			return Date.DayOfWeek.ToString();
		}

		public string DayOfYear(string str)
		{
			SetDateTime(str);
			return Date.DayOfYear.ToString();
		}

		public string Hour(string str)
		{
			SetDateTime(str);
			return Date.Hour.ToString();
		}

		public string Minute(string str)
		{
			SetDateTime(str);
			return Date.Minute.ToString();
		}

		public string Second(string str)
		{
			SetDateTime(str);
			return Date.Second.ToString();
		}

		public string Millisecond(string str)
		{
			SetDateTime(str);
			return Date.Millisecond.ToString();
		}

		public string TimeOfDay(string str)
		{
			SetDateTime(str);
			return Date.TimeOfDay.ToString();
		}

		public string Now()
		{
			Date = DateTime.Now;
			return Date.ToString();
		}

		public string LocalToUniversalTime(string str)
		{
			SetDateTime(str);
			Date = DateTime.SpecifyKind(Date, DateTimeKind.Local);
			return Date.ToUniversalTime().ToString();
		}

		public string UniversalToLocalTime(string str)
		{
			SetDateTime(str);
			Date = DateTime.SpecifyKind(Date, DateTimeKind.Utc);
			return Date.ToUniversalTime().ToString();
		}

		public string AddDays(string str, string offset)
		{
			SetDateTime(str);
			Date = Date.AddDays(Convert.ToDouble(offset));
			return Date.ToString();
		}

		public string AddMonths(string str, string offset)
		{
			SetDateTime(str);
			Date = Date.AddMonths(Convert.ToInt16(offset));
			return Date.ToString();
		}

		public string AddYears(string str, string offset)
		{
			SetDateTime(str);
			Date = Date.AddYears(Convert.ToInt16(offset));
			return Date.ToString();
		}

		public string AddHours(string str, string offset)
		{
			SetDateTime(str);
			Date = Date.AddHours(Convert.ToDouble(offset));
			return Date.ToString();
		}

		public string AddMinutes(string str, string offset)
		{
			SetDateTime(str);
			Date = Date.AddMinutes(Convert.ToDouble(offset));
			return Date.ToString();
		}

		public string AddSeconds(string str, string offset)
		{
			SetDateTime(str);
			Date = Date.AddSeconds(Convert.ToDouble(offset));
			return Date.ToString();
		}

		public string AddMilliseconds(string str, string offset)
		{
			SetDateTime(str);
			Date = Date.AddMilliseconds(Convert.ToDouble(offset));
			return Date.ToString();
		}

		public string IsLeapYear(string str)
		{
			SetDateTime(str);
			return DateTime.IsLeapYear(Date.Year).ToString();
		}

		public string IsDaylightSavingTime(string str)
		{
			SetDateTime(str);
			return Date.IsDaylightSavingTime().ToString();
		}

		public string DaysInMonth(string str)
		{
			SetDateTime(str);
			return DateTime.DaysInMonth(Date.Year,Date.Month).ToString();
		}

		public string FormatStringWithDateTime(string str, string format)
		{
			SetDateTime(str);
			return Date.ToString(format);
		}

        public string Compare(string str1, string str2)
        {
            DateTime d1 = Convert.ToDateTime(str1);
            DateTime d2 = Convert.ToDateTime(str2);
            int result = DateTime.Compare(d1, d2);
            if (result > 0) return "Earlier";
            else if (result < 0) return "Later";
            else return "Equal";
        }

        public string Diff(string str1, string str2)
        {
            DateTime d1 = Convert.ToDateTime(str1);
            DateTime d2 = Convert.ToDateTime(str2);
            return (d1 - d2).ToString();
        }

        public string DiffTotalDays(string str1, string str2)
        {
            DateTime d1 = Convert.ToDateTime(str1);
            DateTime d2 = Convert.ToDateTime(str2);
            return (d1 - d2).TotalDays.ToString();
        }

        public string DiffTotalHours(string str1, string str2)
        {
            DateTime d1 = Convert.ToDateTime(str1);
            DateTime d2 = Convert.ToDateTime(str2);
            return (d1 - d2).TotalHours.ToString();
        }

        public string DiffTotalMinutes(string str1, string str2)
        {
            DateTime d1 = Convert.ToDateTime(str1);
            DateTime d2 = Convert.ToDateTime(str2);
            return (d1 - d2).TotalMinutes.ToString();
        }

        public string DiffTotalSeconds(string str1, string str2)
        {
            DateTime d1 = Convert.ToDateTime(str1);
            DateTime d2 = Convert.ToDateTime(str2);
            return (d1 - d2).TotalSeconds.ToString();
        }

        public string DiffTotalMilliseconds(string str1, string str2)
        {
            DateTime d1 = Convert.ToDateTime(str1);
            DateTime d2 = Convert.ToDateTime(str2);
            return (d1-d2).TotalMilliseconds.ToString();
        }

        public void StartTimer()
        {
            StartDateTime = DateTime.Now;
            IsTiming = true;
        }

        public void StopTimer()
        {
            StopDateTime = DateTime.Now;
            IsTiming = false;
        }

        public string ElapsedMilliseconds()
        {
            TimeSpan ts;
            if (IsTiming) ts = DateTime.Now - StartDateTime;
            else ts = StopDateTime - StartDateTime;
            return ts.TotalMilliseconds.ToString();
        }

        public string ElapsedSeconds()
        {
            TimeSpan ts;
            if (IsTiming) ts = DateTime.Now - StartDateTime;
            else ts = StopDateTime - StartDateTime;
            return ts.TotalSeconds.ToString();
        }

        public string ElapsedMinutes()
        {
            TimeSpan ts;
            if (IsTiming) ts = DateTime.Now - StartDateTime;
            else ts = StopDateTime - StartDateTime;
            return ts.TotalMinutes.ToString();
        }


        public string ElapsedHours()
        {
            TimeSpan ts;
            if (IsTiming) ts = DateTime.Now - StartDateTime;
            else ts = StopDateTime - StartDateTime;
            return ts.TotalHours.ToString();
        }

        public string Elapsed()
        {
            TimeSpan ts;
            if (IsTiming) ts = DateTime.Now - StartDateTime;
            else ts = StopDateTime - StartDateTime;
            return ts.ToString();
        }

        public string RandomDate(string str1, string str2)
        {
            DateTime d1 = Convert.ToDateTime(str1);
            DateTime d2 = Convert.ToDateTime(str2);
            return (d1.AddDays((d1 - d2).TotalDays)).ToString();
        }
    }
}
