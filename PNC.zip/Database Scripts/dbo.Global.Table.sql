use [Automationnew]
GO
/****** Object:  Table [dbo].[Global]    Script Date: 8/23/2016 3:19:35 PM ******/
CREATE TABLE [dbo].[Global](
	[Symbol] [varchar](max) NULL,
	[Company] [varchar](max) NULL,
	[Country] [varchar](max) NULL,
	[Last] [varchar](max) NULL,
	[Date] [varchar](max) NULL,
	[Time] [varchar](max) NULL,
	[Change] [varchar](max) NULL,
	[Percent Change] [varchar](max) NULL,
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
